﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using System.Collections.ObjectModel;
using System.Windows.Data;
using System.ComponentModel;
using Microsoft.Phone.Tasks;

namespace vSongBookInt
{
    public partial class CcSongBook : PhoneApplicationPage
    {
        private AppSettings settings = new AppSettings();
        public CcSongBook()
        {
            InitializeComponent();
            DataContext = App.VirtualSongBook;

            pSongBook.Visibility = Visibility.Collapsed;
            ApplicationBar.IsVisible = false;
            this.Loaded += new RoutedEventHandler(CcSongBook_Loaded);
        }

        private void CcSongBook_Loaded(object sender, RoutedEventArgs e)
        {
            this.NavigationService.RemoveBackEntry();
            
            App.VirtualSongBook.ListTheSongBook();
            ListBox1.ItemsSource = App.VirtualSongBook.SongList.Where(w => w.Content.Contains("Songs of Worship"));
            ListBox2.ItemsSource = App.VirtualSongBook.SongList.Where(w => w.Content.Contains("Believers Songs"));
            ListBox3.ItemsSource = App.VirtualSongBook.SongList.Where(w => w.Content.Contains("Nyimbo za Wokovu"));
            ListBox4.ItemsSource = App.VirtualSongBook.SongList.Where(w => w.Content.Contains("Redemption Songs"));
            ListBox5.ItemsSource = App.VirtualSongBook.SongList.Where(w => w.Content.Contains("Chichewa Songs"));

            pSongBook.Visibility = Visibility.Visible;
            ApplicationBar.IsVisible = true;
        }

        private void ListBox1_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (ListBox1.SelectedIndex == -1)
                return;
            vsb_songbook myresults = ListBox1.SelectedItem as vsb_songbook;
            //settings.CurrSongSetting = myresults.ID - 1;
            NavigationService.Navigate(new Uri("/CcSongView.xaml?selectedSong=" + (myresults.ID - 1).ToString(), UriKind.Relative));
            
            ListBox1.SelectedIndex = -1;
        }

        private void ListBox2_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (ListBox2.SelectedIndex == -1)
                return;
            vsb_songbook myresults = ListBox2.SelectedItem as vsb_songbook;
            //settings.CurrSongSetting = myresults.ID - 1;
            NavigationService.Navigate(new Uri("/CcSongView.xaml?selectedSong=" + (myresults.ID - 1).ToString(), UriKind.Relative));
            
            ListBox2.SelectedIndex = -1;
        }

        private void ListBox3_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (ListBox3.SelectedIndex == -1)
                return;
            vsb_songbook myresults = ListBox3.SelectedItem as vsb_songbook;
            //settings.CurrSongSetting = myresults.ID - 1;
            NavigationService.Navigate(new Uri("/CcSongView.xaml?selectedSong=" + (myresults.ID - 1).ToString(), UriKind.Relative));
            
            ListBox3.SelectedIndex = -1;
        }

        private void ListBox4_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (ListBox4.SelectedIndex == -1)
                return;
            vsb_songbook myresults = ListBox4.SelectedItem as vsb_songbook;
            //settings.CurrSongSetting = myresults.ID - 1;
            NavigationService.Navigate(new Uri("/CcSongView.xaml?selectedSong=" + (myresults.ID - 1).ToString(), UriKind.Relative));
            
            ListBox4.SelectedIndex = -1;
        }

        private void ListBox5_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (ListBox5.SelectedIndex == -1)
                return;
            vsb_songbook myresults = ListBox5.SelectedItem as vsb_songbook;
            //settings.CurrSongSetting = myresults.ID - 1;
            NavigationService.Navigate(new Uri("/CcSongView.xaml?selectedSong=" + (myresults.ID - 1).ToString(), UriKind.Relative));
            
            ListBox5.SelectedIndex = -1;
        }

        public void Searchable(object sender, EventArgs e)
        {
            NavigationService.Navigate(new Uri("/CcSearchable.xaml", UriKind.Relative));
        }

        private void MyOwnSongs(object sender, EventArgs e)
        {
            NavigationService.Navigate(new Uri("/DdOwnSongs.xaml", UriKind.Relative));
        }

        private void MyFavourites(object sender, EventArgs e)
        {
            NavigationService.Navigate(new Uri("/DdFavourites.xaml", UriKind.Relative));
        }

        public void MySettings(object sender, EventArgs e)
        {
            NavigationService.Navigate(new Uri("/FfSettings.xaml", UriKind.Relative));
        }


        public void AppTutorial(object sender, EventArgs e)
        {
            NavigationService.Navigate(new Uri("/BbDemo.xaml", UriKind.Relative));
        }

        public void HowItWorks(object sender, EventArgs e)
        {
            NavigationService.Navigate(new Uri("/EeHowItWorks.xaml", UriKind.Relative));
        }


        public void AboutThisApp(object sender, EventArgs e)
        {
            NavigationService.Navigate(new Uri("/EeInformation.xaml", UriKind.Relative));
        }


    }
}