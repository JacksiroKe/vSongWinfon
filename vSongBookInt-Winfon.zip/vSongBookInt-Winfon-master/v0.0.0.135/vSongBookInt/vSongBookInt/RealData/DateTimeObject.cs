﻿using System;

namespace vSongBookInt.RealData
{
    public class DateTimeObject
    {
        public DateTime DateAndTime { get; set; }

        public DateTimeObject(DateTime dt)
        {
            DateAndTime = dt;
        }
    }
}
