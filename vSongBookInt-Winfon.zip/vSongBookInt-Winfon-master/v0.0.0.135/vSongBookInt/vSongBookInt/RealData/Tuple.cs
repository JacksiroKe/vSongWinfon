﻿namespace vSongBookInt.RealData
{
    public class Tuple<T, U>
    {
        public T Item1
        {
            get;
            set;
        }

        public U Item2
        {
            get;
            set;
        }
    }
}
